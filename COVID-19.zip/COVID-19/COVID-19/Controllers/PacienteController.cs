﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using COVID_19.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace COVID_19.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PacienteController : ControllerBase
    {
        [HttpGet]
        public async Task<IActionResult> Get() 
        {
            return Ok("Lista de todos os Pacientes");
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            return Ok("Detalhes do paciente");
        }
        [HttpPost]
        public async Task<IActionResult> Post(Paciente paciente)
        {
            if (string.IsNullOrEmpty(paciente.nome)) {
                return BadRequest("Titulo está vazio, tente novamente!");
            }
            return Ok("Paciente Cadastrado com sucesso");
        }

    }
}
